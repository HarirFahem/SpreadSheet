#include "godialog.h"
#include "ui_godialog.h"
#include "QRegExp"
#include "QRegExpValidator"
#include "godialog.h"
GoDialog::GoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GoDialog)
{
    ui->setupUi(this);
    //Définir l'expression nregulière
    QRegExp reg{"[A-Z][1-9][0-9]"};
    //validateur pour le lineedit
    ui->lineEdit_2->setValidator(new QRegExpValidator(reg));

}
QString GoDialog::getText()const
{
    return ui->lineEdit_2->text();
}
GoDialog::~GoDialog()
{
    delete ui;
}
