#ifndef SPREADSHEET_H
#define SPREADSHEET_H

#include <QMainWindow>
#include <QTableWidget>
#include <QAction>
#include <QMenu>
#include <QToolBar>
#include <QLabel>
#include <QStatusBar>
#include "QTableWidgetSelectionRange"
#include "QClipboard"
#include "QMutableStringListIterator"
#include "QSettings"

class SpreadSheet : public QMainWindow
{
    Q_OBJECT

public:
    SpreadSheet(QWidget *parent = nullptr);
    ~SpreadSheet();

protected:
    void setupMainWidget();
    void createActions();
    void createMenus();
    void createToolBars();
    void makeConnexions();

private slots:
    void close();
    void updateStatusBar(int, int); //Respond for the call changed
    void GotoCellSlots();
    void Search();
    void saveslot(); //slot pour répondre à l'appel save
    void Open();
    void newfile();
    void deletecell();
    void aboutSlot();
    void aboutQtSlot();
    void openRecentFile();
    void SaveAsSlot();
    void copySlot();
    void pasteSlot();
    void cutSlot();

private:
    void saveContent(QString fileName); //method pour sauvegarder le contenu
     void OpenContent(QString fileName );//method pour ouvrir le contenu
     void loadcsv(QString fileName);
 //Pointers
private:
    // --------------- Central Widget -------------//
    QTableWidget *spreadsheet;
    // --------------- Actions       --------------//
    QAction * newFile;
    QAction * open;
    QAction * save;
    QAction * saveAs;
    QAction * exit;
    QAction *cut;
    QAction *copy;
    QAction *paste;
    QAction *deleteAction;
    QAction *find;
    QAction *row;
    QAction *Column;
    QAction *all;
    QAction *goCell;
    QAction *recalculate;
    QAction *sort;
    QAction *showGrid;
    QAction *auto_recalculate;
    QAction *about;
    QAction *aboutQt;
    QAction *deleteall;
    QAction *recfiles;

    QList<QAction*> recentFileActions;
    const int maxFileNr;
    QAction* recentFileAction=0;

    // ---------- Menus ----------
    QMenu *FileMenu;
    QMenu *editMenu;
    QMenu *toolsMenu;
    QMenu *optionsMenu;
    QMenu *helpMenu;
    QMenu *recentFilesMenu;

    QClipboard *clipboard;

    //  ----- - Widget pouyr la bare d'etat
    QLabel *cellLocation;  //position de la cellule active
    QLabel *cellFormula;   // Formuel de la cellue active

    //nom du fichier courant
    QString * currentFile;

};

#endif // SPREADSHEET_H
