/********************************************************************************
** Form generated from reading UI file 'GoDialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GODIALOG_H
#define UI_GODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_GoDialog
{
public:
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_3;
    QPushButton *OkButton_2;

    void setupUi(QDialog *GoDialog)
    {
        if (GoDialog->objectName().isEmpty())
            GoDialog->setObjectName(QString::fromUtf8("GoDialog"));
        GoDialog->resize(268, 84);
        verticalLayout_3 = new QVBoxLayout(GoDialog);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(GoDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_3->addWidget(label_2);

        lineEdit_2 = new QLineEdit(GoDialog);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        horizontalLayout_3->addWidget(lineEdit_2);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_2 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        pushButton_3 = new QPushButton(GoDialog);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        horizontalLayout_4->addWidget(pushButton_3);

        OkButton_2 = new QPushButton(GoDialog);
        OkButton_2->setObjectName(QString::fromUtf8("OkButton_2"));
        OkButton_2->setEnabled(true);

        horizontalLayout_4->addWidget(OkButton_2);


        verticalLayout_2->addLayout(horizontalLayout_4);


        verticalLayout_3->addLayout(verticalLayout_2);

#if QT_CONFIG(shortcut)
#endif // QT_CONFIG(shortcut)

        retranslateUi(GoDialog);
        QObject::connect(pushButton_3, SIGNAL(clicked()), GoDialog, SLOT(reject()));
        QObject::connect(OkButton_2, SIGNAL(clicked()), GoDialog, SLOT(accept()));

        OkButton_2->setDefault(true);


        QMetaObject::connectSlotsByName(GoDialog);
    } // setupUi

    void retranslateUi(QDialog *GoDialog)
    {
        GoDialog->setWindowTitle(QCoreApplication::translate("GoDialog", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("GoDialog", "&Cell Location :", nullptr));
        pushButton_3->setText(QCoreApplication::translate("GoDialog", "Cancel", nullptr));
        OkButton_2->setText(QCoreApplication::translate("GoDialog", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GoDialog: public Ui_GoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GODIALOG_H
