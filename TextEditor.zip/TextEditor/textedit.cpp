#include "textedit.h"
#include "ui_textedit.h"
#include<QFileDialog>
#include<QFile>
#include<QMessageBox>

Textedit::Textedit(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Textedit)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->textEdit);
    setWindowTitle("WordText");
}

Textedit::~Textedit()
{
    delete ui;
}


void Textedit::on_actionNew_triggered()
{
  Filename= "";
  ui->textEdit->setPlainText("");
}


void Textedit::on_actionOpen_triggered()
{
 QString file = QFileDialog::getOpenFileName(this,"Open file");

  if(!file.isEmpty()){
         QFile sFile(file);
         if(sFile.open(QFile::ReadOnly | QFile::Text)){
            Filename= file ;
             QTextStream in(&sFile);
              QString text = in.readAll();
              sFile.close();
              ui->textEdit->setPlainText(text);

         }

}
}


void Textedit::on_actionCut_triggered()
{
 ui->textEdit->cut();
}


void Textedit::on_action_Save_triggered()
{
  QFile sFile(Filename);
  if(sFile.open(QFile::WriteOnly | QFile::Text)){
      QTextStream out (&sFile);
      out  <<  ui->textEdit->toPlainText();
      sFile.flush();
      sFile.close();

  }
}


void Textedit::on_actionSave_As_triggered()
{
    QString file = QFileDialog::getSaveFileName(this,"Open file");

     if(!file.isEmpty()){

        Filename = file;
        on_action_Save_triggered();

            }


}


void Textedit::on_actionE_xit_triggered()
{
  ui->centralwidget->close();
}


void Textedit::on_action_Copy_triggered()
{
 ui->textEdit->copy();
}


void Textedit::on_action_Paste_triggered()
{
  ui->textEdit->paste();
}


void Textedit::on_action_About_triggered()
{
    QMessageBox::about(this,"about", "My Text editor");


}


void Textedit::on_actionAbout_Qt_triggered()
{
QMessageBox::aboutQt(this, "Your Qt");
}


void Textedit::on_actionUndo_triggered()
{
    ui->textEdit->undo();
}



void Textedit::on_actionRedo_triggered()
{
    ui->textEdit->redo();
}

