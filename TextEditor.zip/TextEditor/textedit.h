#ifndef TEXTEDIT_H
#define TEXTEDIT_H

#include <QMainWindow>
#include <QtCore>
#include <QtGui>


QT_BEGIN_NAMESPACE
namespace Ui { class Textedit; }
QT_END_NAMESPACE

class Textedit : public QMainWindow
{
    Q_OBJECT

public:
    Textedit(QWidget *parent = nullptr);
    ~Textedit();

private slots:
    void on_actionNew_triggered();

    void on_actionOpen_triggered();

    void on_actionCut_triggered();

    void on_action_Save_triggered();

    void on_actionSave_As_triggered();

    void on_actionE_xit_triggered();

    void on_action_Copy_triggered();

    void on_action_Paste_triggered();

    void on_action_About_triggered();

    void on_actionAbout_Qt_triggered();

    void on_actionUndo_triggered();

    void on_actionRedo_triggered();

private:
    Ui::Textedit *ui;
    QString Filename;
};
#endif // TEXTEDIT_H
