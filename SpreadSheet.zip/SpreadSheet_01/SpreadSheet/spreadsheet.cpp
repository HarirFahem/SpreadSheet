#include "spreadsheet.h"
#include <QPixmap>
#include <QMenuBar>
#include <QToolBar>
#include <QApplication>
#include <QMessageBox>
#include "godialog.h"
#include "finddialog.h"
#include "QFileDialog"
#include "QTextStream"
SpreadSheet::SpreadSheet(QWidget *parent)
    : QMainWindow(parent) , maxFileNr(5)
{
    //Seting the spreadsheet
    setupMainWidget();

    // Creaeting Actions
    createActions();

    // Creating Menus
    createMenus();


    //Creating the tool bar
    createToolBars();

    //making the connexions
    makeConnexions();



    //Creating the labels for the status bar (should be in its proper function)
    cellLocation = new QLabel("(1, 1)");
    cellFormula = new QLabel("");
    statusBar()->addPermanentWidget(cellLocation);
    statusBar()->addPermanentWidget(cellFormula);
    //initialiser le nom du fichier courant
    currentFile=nullptr;
    //mettre le nom du spreadsheet
    setWindowTitle("SpreadSheet");
}

void SpreadSheet::setupMainWidget()
{
    spreadsheet = new QTableWidget;
    spreadsheet->setRowCount(100);
    spreadsheet->setColumnCount(20);
    setCentralWidget(spreadsheet);
}

SpreadSheet::~SpreadSheet()
{
    delete spreadsheet;
    // --------------- Actions       --------------//
    delete  newFile;
    delete  open;
    delete  save;
    delete  saveAs;
    delete  exit;
    delete cut;
    delete copy;
    delete paste;
    delete deleteAction;
    delete find;
    delete row;
    delete Column;
    delete all;
    delete goCell;
    delete recalculate;
    delete sort;
    delete showGrid;
    delete auto_recalculate;
    delete about;
    delete aboutQt;

    // ---------- Menus ----------
    delete FileMenu;
    delete editMenu;
    delete toolsMenu;
    delete optionsMenu;
    delete helpMenu;
}

void SpreadSheet::createActions()
{
   // --------- New File -------------------
   QPixmap newIcon(":/new_file.png");
   newFile = new QAction(newIcon, "&New", this);
   newFile->setShortcut(tr("Ctrl+N"));


    // --------- open file -------------------
   QPixmap openIcon(":/open_icon.png");
   open = new QAction(openIcon,"&Open", this);
   open->setShortcut(tr("Ctrl+O"));

    // --------- open file -------------------
   QPixmap saveIcon(":/save_icon.png");
   save = new QAction(saveIcon,"&Save", this);
   save->setShortcut(tr("Ctrl+S"));

   // --------- open file -------------------
   QPixmap saveAsIcon(":/save_as_icon.png");
   saveAs = new QAction(saveAsIcon,"save &As", this);


   // --------- open file -------------------
   QPixmap cutIcon(":/cut_icon.png");
   cut = new QAction(newIcon, "Cu&t", this);
   cut->setShortcut(tr("Ctrl+X"));

   // --------- Cut menu -----------------
   QPixmap copyIcon(":/copy_icon.png");
   copy = new QAction(copyIcon, "&Copy", this);
   copy->setShortcut(tr("Ctrl+C"));

   QPixmap pasteIcon(":/paste_icon.png");
   paste = new QAction(pasteIcon, "&Paste", this);
   paste->setShortcut(tr("Ctrl+V"));

   QPixmap deleteIcon(":/delete_icon.png");
   deleteAction = new QAction(deleteIcon, "&Delete", this);
   deleteAction->setShortcut(tr("Del"));

   QPixmap deleteAllIcon(":/delete_all_icon.png");
   deleteall = new QAction(deleteAllIcon, "&DeleteAll", this);
   deleteall->setShortcut(tr("DelAll"));

   QPixmap rowIcon(":/row_icon.png");
   row  = new QAction(rowIcon,"&Row", this);

   QPixmap columnIcon(":/column_icon.png");
   Column = new QAction(columnIcon,"&Column", this);

   QPixmap allIcon(":/all_icon.png");
   all = new QAction(allIcon,"&All", this);
   all->setShortcut(tr("Ctrl+A"));



   QPixmap findIcon(":/search_icon.png");
   find= new QAction(newIcon, "&Find", this);
   find->setShortcut(tr("Ctrl+F"));

   QPixmap goCellIcon(":/go_to_icon.png");
   goCell = new QAction( goCellIcon, "&Go to Cell", this);
   deleteAction->setShortcut(tr("f5"));

   QPixmap recalculateIcon(":/recalculate_icon.png");
   recalculate = new QAction(recalculateIcon,"&Recalculate",this);
   recalculate->setShortcut(tr("F9"));

   QPixmap sortIcon(":/sort_icon.png");
   sort = new QAction(sortIcon,"&Sort");



   showGrid = new QAction("&Show Grid");
   showGrid->setCheckable(true);
   showGrid->setChecked(spreadsheet->showGrid());

   auto_recalculate = new QAction("&Auto-recalculate");
   auto_recalculate->setCheckable(true);
   auto_recalculate->setChecked(true);


   QPixmap aboutIcon(":/about_icon.png");
   about =  new QAction(aboutIcon,"&About");
   QPixmap aboutQtIcon(":/about_qt_icon.png");
   aboutQt = new QAction(aboutQtIcon,"About &Qt");

   // --------- exit -------------------
   QPixmap exitIcon(":/quit_icon.png");
   exit = new QAction(exitIcon,"E&xit", this);
   exit->setShortcut(tr("Ctrl+Q"));
}

void SpreadSheet::close()
{

    auto reply = QMessageBox::question(this, "Exit","Do you really want to quit?");
    if(reply == QMessageBox::Yes)
        qApp->exit();
}

void SpreadSheet::createMenus()
{
    // --------  File menu -------//
    FileMenu = menuBar()->addMenu("&File");
    FileMenu->addAction(newFile);
    FileMenu->addAction(open);
    FileMenu->addAction(save);
    FileMenu->addAction(saveAs);
    FileMenu->addSeparator();
    QPixmap recentIcon(":/recent_icon.png");
    recentFilesMenu = FileMenu->addMenu(recentIcon,tr("&Open Recent"));
    FileMenu->addSeparator();
    FileMenu->addAction(exit);


    //------------- Edit menu --------/
    editMenu = menuBar()->addMenu("&Edit");
    editMenu->addAction(cut);
    editMenu->addAction(copy);
    editMenu->addAction(paste);
    editMenu->addAction(deleteAction);
    editMenu->addAction(deleteall);
    editMenu->addSeparator();
    QPixmap selectIcon(":/select_icon.png");
    auto select = editMenu->addMenu(selectIcon,"&Select");
    select->addAction(row);
    select->addAction(Column);
    select->addAction(all);

    editMenu->addAction(find);
    editMenu->addAction(goCell);

    //-------------- Toosl menu ------------
    toolsMenu = menuBar()->addMenu("&Tools");
    toolsMenu->addAction(recalculate);
    toolsMenu->addAction(sort);

    //Optins menus
    optionsMenu = menuBar()->addMenu("&Options");
    optionsMenu->addAction(showGrid);
    optionsMenu->addAction(auto_recalculate);


    //----------- Help menu ------------
    helpMenu = menuBar()->addMenu("&Help");
    helpMenu->addAction(about);
    helpMenu->addAction(aboutQt);
}

void SpreadSheet::createToolBars()
{

    //Creer une barre d'outils
    auto toolbar1 = addToolBar("File");


    //Ajouter des actions a cette bar
    toolbar1->addAction(newFile);
    toolbar1->addAction(save);
    toolbar1->addSeparator();
    toolbar1->addAction(exit);
    toolbar1->addAction(open);
    toolbar1->addAction(saveAs);


    //Creer une autre tool bar
    auto toolbar2  = addToolBar("ToolS");
    toolbar2->addAction(goCell);
    toolbar2->addAction(all);
}

void SpreadSheet::updateStatusBar(int row, int col)
{
    QString cell{"(%0, %1)"};
   cellLocation->setText(cell.arg(row+1).arg(col+1));

}

void SpreadSheet::makeConnexions()
{

   // --------- Connexion for the  select all action ----/
   connect(all, &QAction::triggered,spreadsheet, &QTableWidget::selectAll);
   connect(row, &QAction::triggered,spreadsheet, &QTableWidget::selectRow);
   connect(Column, &QAction::triggered, spreadsheet, &QTableWidget::selectColumn);
   //connection for the clear all
   connect(deleteall, &QAction::triggered,spreadsheet, &QTableWidget::clearContents);
   //connection for the delete cell content
   connect(deleteAction, &QAction::triggered,this, &SpreadSheet::deletecell);


   // Connection for the  show grid
   connect(showGrid, &QAction::triggered,spreadsheet, &QTableWidget::setShowGrid);

   //Connection for the exit button
   connect(exit, &QAction::triggered, this, &SpreadSheet::close);


   //connectting the chane of any element in the spreadsheet with the update status bar
   connect(spreadsheet, &QTableWidget::cellClicked, this,  &SpreadSheet::updateStatusBar);
   //connection entre le go et le slot
   connect(goCell,&QAction::triggered,this,&SpreadSheet::GotoCellSlots);
   connect(find,&QAction::triggered,this,&SpreadSheet::Search);
   //connection de save file
   connect(save, &QAction::triggered,this,&SpreadSheet::saveslot);
   //connection du open file
   connect(open,&QAction::triggered,this,&SpreadSheet::Open);
   //connection du new file
   connect(newFile,&QAction::triggered,this,&SpreadSheet::newfile);
   //connect du slot
   connect(about,&QAction::triggered,this,&SpreadSheet::aboutSlot);
   //connect du Qtslot
   connect(aboutQt,&QAction::triggered,this,&SpreadSheet::aboutQtSlot);
   //connect du recent files
  // connect(recentFileAction,&QAction::triggered,this,&SpreadSheet::openRecentFile);
   //connect saveas
   connect(saveAs,&QAction::triggered,this,&SpreadSheet::SaveAsSlot);
   //connexion of copy and paste
   connect(copy, &QAction::triggered, this, &SpreadSheet::copySlot);
   connect(paste, &QAction::triggered, this, &SpreadSheet::pasteSlot);

}
void SpreadSheet::Search()
{
  FindDialog F;
  auto repl = F.exec();

  if(repl == FindDialog::Accepted){
      auto text=F.getText();

      for(auto i =0;i<spreadsheet->rowCount();i++){
          for(auto j =0;j<spreadsheet->columnCount();j++){
            if(spreadsheet-> item(i,j)!=nullptr && spreadsheet-> item(i,j)->text().contains(text) )
                spreadsheet->setCurrentCell( i, j);

      }
    }
  }

}
void SpreadSheet::GotoCellSlots()
{
    //declarer le dialog
    GoDialog D;
    //l'executer
    auto repl = D.exec();
    if(repl==GoDialog::Accepted)
    {  //extraire le row et le column
        auto text = D.getText();
        int row = text[0].toLatin1()-'A';
        //supprimer le premier caractere
        text= text.remove(0,1);
        int col =text.toInt();
        spreadsheet->setCurrentCell(row,col);
    }

}
void SpreadSheet::saveslot()
{
  //vérifier si on a pas un nom de fichier
    if(!currentFile){
        QFileDialog D;
        auto filename=D.getSaveFileName();
        //changer le nom du fichier
        currentFile=new QString(filename);
        //changer le title de l'application
        setWindowTitle(*currentFile);
    }
    //fonction privée pour sauvergarder le contenu
    saveContent(*currentFile);
}
void SpreadSheet::saveContent(QString fileName)
{

    //ouvrir le fichier en mode de lecture
    QFile file(fileName);
    if(file.open(QIODevice::WriteOnly)){
     QTextStream out(&file);
     //boucle sur les cellules pour sauvergarder leur contenu
     for(int i=0;i<spreadsheet->rowCount();i++)
         for(int j=0;j<spreadsheet->columnCount();j++)
         {
             auto cell = spreadsheet->item(i,j);
             if(cell){
                 out <<i << "," <<j <<","<< cell->text() << endl;
             }
         }
    }
    //fermer la connexion avec le fichier
    file.close();

}
void SpreadSheet::Open(){

    QFileDialog D;
        auto filename=D.getOpenFileName(this,("open file"));

        currentFile = new QString(filename);
           setWindowTitle(*currentFile);
           if (currentFile->endsWith(".csv")){
                     loadcsv(filename);
                    } else {OpenContent(filename);}



        int i=0;
        if(i<maxFileNr)
        {
        recentFileActions.append(new QAction( *currentFile,this));

        recentFilesMenu->addAction(recentFileActions[i]);
        //connexion
        connect(recentFileActions[i], &QAction::triggered, this, &SpreadSheet::openRecentFile);

        i++;

        }
        else{
        for (int j=0;j<4 ;j++ ) {
        recentFileActions[4-j]->setText(recentFileActions[3-j]->text());

        }
        recentFileActions[0]->setText(*currentFile);

      }
}
void SpreadSheet::OpenContent(QString fileName){
    QFile file(fileName);
    if(file.open(QIODevice::ReadOnly)){
            QTextStream in(&file);
            while(!in.atEnd()){
                QString line;
                line=in.readLine();
                //separer par virgule
                auto tokens = line.split(QChar(','));
                //num row
                int row=tokens[0].toInt();
                int col=tokens[1].toInt();
                auto cell = new QTableWidgetItem(tokens[2]);
                spreadsheet->setItem(row,col,cell);
            }
}

}
void SpreadSheet::newfile(){


    SpreadSheet *mainWin = new SpreadSheet;
                 mainWin->show();
}
void SpreadSheet::deletecell(){

    foreach (QTableWidgetItem *i, spreadsheet->selectedItems())
                i->setText("");

}
void SpreadSheet::aboutSlot(){
    QMessageBox::about(this,"about", "My spreadsheet!!");
}

void SpreadSheet::aboutQtSlot(){
    QMessageBox::aboutQt(this, "Your Qt");
}
void SpreadSheet::SaveAsSlot(){
    if(!currentFile)
    {
        QFileDialog D;
        auto filename=D.getSaveFileName(this,("save file"),"",("csv File(*.csv);;Text files (*.txt);;XML files (*.xml);;All files (*.*)"));
        //changer le nom de fichier
        currentFile = new QString(filename);
        //changer le title de l'application
        setWindowTitle(*currentFile);

    }
    saveContent(*currentFile);
}
void SpreadSheet::loadcsv(QString filename){
    QFile file(filename);
    if (file.open(QIODevice::ReadOnly )) {
        QTextStream in(&file);

 int i=0;
    while (!in.atEnd()) {
        QString line = in.readLine();
        // now, line will be a string of the whole line, if you're trying to read a CSV or something, you can split the string
        auto list = line.split(QChar(';'));
        // process the line here

        for(int j=0;j<list.length();j++){
            auto contenu=new  QTableWidgetItem (list[j]);
             spreadsheet->setItem(i,j,contenu);

        }
        i++;

    }
}
}
void SpreadSheet::cutSlot()
{
     copySlot();
     deletecell();
}
void SpreadSheet::copySlot(){
    clipboard->clear();
    auto cell = spreadsheet->currentItem();
    if(cell)
        clipboard->setText(cell->text(), QClipboard::Clipboard);
}

void SpreadSheet::pasteSlot(){
    spreadsheet->setItem(spreadsheet->currentRow(), spreadsheet->currentColumn(),new QTableWidgetItem(clipboard->text()));
}
void SpreadSheet::openRecentFile()
{
    auto b = dynamic_cast<QAction*>(sender());
    QFile file(b->text());
    QString line;
    if(file.open(QIODevice::ReadOnly))
    {
    QTextStream in(&file);
    while( !in.atEnd())
    {
    line = in.readLine();
    auto tokens = line.split(QChar(',') );
    int row = tokens[0].toInt();
    int col = tokens[1].toInt();
    spreadsheet->setItem(row, col , new QTableWidgetItem(tokens[2]));
    }

    }

    *currentFile = (b->text()) ;
    setWindowTitle(*currentFile);

    file.close();
}


